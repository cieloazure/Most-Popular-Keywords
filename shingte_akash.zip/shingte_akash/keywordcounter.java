public class keywordcounter {
    /**
     * Main program to have a executable in a specified name
     * @param args
     */
    public static void main(String args[]) {
        Runner.run(args);
    }
}
